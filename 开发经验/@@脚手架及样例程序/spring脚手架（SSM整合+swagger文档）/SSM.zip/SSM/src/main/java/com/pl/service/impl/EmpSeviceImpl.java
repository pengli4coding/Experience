package com.pl.service.impl;

import com.pl.Req.EmpReq;
import com.pl.dao.EmpDao;
import com.pl.model.Emp;
import com.pl.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmpSeviceImpl implements EmpService {

    @Autowired
    private EmpDao empdao;

    @Override
    public List<Emp> getAllEmps() {
        return empdao.getAllEmps();
    }

    @Override
    public Emp getEmpById(EmpReq req) {
        return empdao.getEmpById(req);
    }
}
