package com.pl.service.impl;

import com.pl.dao.View1Dao;
import com.pl.model.View1Data;
import com.pl.service.View1Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class View1ServiceImpl implements View1Service {

    @Autowired
    private View1Dao view1Dao;

    @Override
    public List<View1Data> getAllData() {
        return view1Dao.getAllData();
    }
}
