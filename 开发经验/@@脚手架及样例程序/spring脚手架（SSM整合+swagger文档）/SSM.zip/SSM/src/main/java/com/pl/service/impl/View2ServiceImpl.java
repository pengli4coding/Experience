package com.pl.service.impl;

import com.pl.dao.View2Dao;
import com.pl.model.View2Data;
import com.pl.service.View2Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class View2ServiceImpl implements View2Service {

    @Autowired
    private View2Dao view2Dao;

    @Override
    public List<View2Data> getAllData() {
        return view2Dao.getAllData();
    }
}
