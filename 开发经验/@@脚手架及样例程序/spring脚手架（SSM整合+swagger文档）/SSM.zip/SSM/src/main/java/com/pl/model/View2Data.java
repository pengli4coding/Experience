package com.pl.model;

public class View2Data {

    private String empName;
    private String cardNo;

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    @Override
    public String toString() {
        return "View2Data{" +
                "empName='" + empName + '\'' +
                ", cardNo='" + cardNo + '\'' +
                '}';
    }
}
