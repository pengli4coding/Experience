package com.pl.dao;

import com.pl.model.View1Data;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface View1Dao {

    List<View1Data> getAllData();

}
