package com.pl.service;

import com.pl.model.View1Data;

import java.util.List;

public interface View1Service {

    List<View1Data> getAllData();

}
