package com.pl.service;

import com.pl.model.View2Data;

import java.util.List;

public interface View2Service {

    List<View2Data> getAllData();

}
