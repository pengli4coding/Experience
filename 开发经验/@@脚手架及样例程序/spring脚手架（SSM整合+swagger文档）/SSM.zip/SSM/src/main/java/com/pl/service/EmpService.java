package com.pl.service;

import com.pl.Req.EmpReq;
import com.pl.model.Emp;

import java.util.List;

public interface EmpService {

    List<Emp> getAllEmps();

    Emp getEmpById(EmpReq req);
}
