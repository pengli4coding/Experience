package com.pl.controller;

import com.pl.model.View1Data;
import com.pl.service.View1Service;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;


@Controller
@RequestMapping("/view1")
@Api(description = "查询数据库视图view1的接口集合")
public class View1Controller {

    private static final Logger log = LogManager.getLogger();

    @Autowired
    private View1Service view1Service;

    @RequestMapping("/getAllData")
    @ApiOperation(value = "查询数据库视图view1的所有数据",httpMethod = "POST")
    @ResponseBody
    public List<View1Data> getAllData(){
        log.info("打印一段日志，说明进来了");
        List<View1Data> list = view1Service.getAllData();
        return list;
    }


}
