package com.pl.controller;

import com.pl.Req.EmpReq;
import com.pl.model.Emp;
import com.pl.service.EmpService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.validation.Valid;
import java.util.List;


@Controller
@RequestMapping("/emp")
@Api(description = "雇员信息接口集合")
public class EmpController {

    private static final Logger log = LogManager.getLogger();

    @Autowired
    private EmpService empService;


    @RequestMapping("/getAllEmps")
    @ApiOperation(value = "获取所有的雇员信息",httpMethod = "POST")
    @ResponseBody
    public List<Emp> getAllEmps(){
        log.info("打印一段日志，说明进来了");
        List<Emp> list = empService.getAllEmps();
        return list;
    }

    @RequestMapping("/getEmpById")
    @ApiOperation(value = "根据id获取雇员信息",httpMethod = "POST")
    @ResponseBody
    public Emp getEmpById(@Valid EmpReq req){
        log.info("打印一段日志，说明进来了");
        Emp emp = empService.getEmpById(req);
        return emp;
    }
}
