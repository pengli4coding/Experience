package com.pl.dao;

import com.pl.model.View2Data;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface View2Dao {

    List<View2Data> getAllData();

}
