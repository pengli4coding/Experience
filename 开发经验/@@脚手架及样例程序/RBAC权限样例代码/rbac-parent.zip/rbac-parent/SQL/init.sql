DROP TABLE IF EXISTS t_test;

CREATE TABLE t_test (
  ID int(11) unsigned NOT NULL AUTO_INCREMENT,
  PET varchar(255) NOT NULL,
  PRIMARY KEY (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert  into t_test (ID,PET) values
(1,'大肥猫'),
(2,'大黄猫');


DROP TABLE IF EXISTS t_user;

CREATE TABLE t_user (
  ID int(11) unsigned NOT NULL AUTO_INCREMENT,
  USERNAME varchar(255) NOT NULL COMMENT '用户名',
  LOGINACCT varchar(255) NOT NULL COMMENT '登录账号',
  USERPSWD varchar(255) NOT NULL COMMENT '登录密码',
  EMAIL varchar(255) NOT NULL COMMENT '邮箱',
  PRIMARY KEY (`ID`)
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_general_ci
COMMENT='用户表';

insert  into t_user (ID,USERNAME,LOGINACCT,USERPSWD,EMAIL) values
(1,'超级管理员','admin','123456','pengli4coding@163.com'),
(2,'熊斌','xb','123456','123456789@qq.com'),
(3,'张小珊','zxs','123456','123456789@qq.com');



DROP TABLE IF EXISTS t_role;

CREATE TABLE t_role (
  ID int(11) unsigned NOT NULL AUTO_INCREMENT,
  ROLENAME varchar(255) NOT NULL COMMENT '角色名',
  PRIMARY KEY (`ID`)
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_general_ci
COMMENT='角色表';

insert  into t_role (ID,ROLENAME) values
(1,'PM - 项目经理'),
(2,'SE - 软件工程师'),
(3,'PG - 程序员'),
(4,'TL - 组长'),
(5,'QA - 品质保证'),
(6,'QC - 品质控制'),
(7,'SA - 软件架构师'),
(8,'CMO/CMS - 配置管理员');

DROP TABLE IF EXISTS t_user_role;

CREATE TABLE t_user_role(
  ID INT(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  USER_ID INT(11) NOT NULL COMMENT '用户id',
  ROLE_ID INT(11) NOT NULL COMMENT '角色id',
  PRIMARY KEY (ID)
) ENGINE=INNODB CHARSET=utf8 COLLATE=utf8_general_ci
COMMENT='用户角色关联表';



