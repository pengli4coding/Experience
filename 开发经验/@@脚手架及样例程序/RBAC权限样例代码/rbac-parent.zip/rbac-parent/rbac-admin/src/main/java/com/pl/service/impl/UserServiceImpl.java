package com.pl.service.impl;

import com.pl.dao.UserDao;
import com.pl.entity.User;
import com.pl.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    @Override
    public User query4Login(User user) {
        return userDao.query4Login(user);
    }

    @Override
    public List<User> paginationQuery(Map<String, Object> queryMap) {
        return userDao.paginationQuery(queryMap);
    }

    @Override
    public int paginationCount(Map<String, Object> queryMap) {
        return userDao.paginationCount(queryMap);
    }

    @Override
    public void addUser(User user) {
        userDao.addUser(user);
    }
}
