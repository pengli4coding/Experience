package com.pl.service;

import com.pl.entity.User;

import java.util.List;
import java.util.Map;

public interface UserService {

    User query4Login(User user);

    List<User> paginationQuery(Map<String, Object> queryMap);

    int paginationCount(Map<String, Object> queryMap);

    void addUser(User user);

}
