package com.pl.dao;

import com.pl.entity.User;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface UserDao {

    @Select("select * from t_user where loginacct = #{loginacct} and userpswd =#{userpswd}")
    User query4Login(User user);

    List<User> paginationQuery(Map<String, Object> queryMap);

    int paginationCount(Map<String, Object> queryMap);

    void addUser(User user);
}
