package com.pl.controller;

import com.pl.entity.PaginationResult;
import com.pl.entity.User;
import com.pl.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping("/add")
    public String add(){
        return "user/add";
    }

    @RequestMapping("/addUser")
    @ResponseBody
    public Object addUser(User user){
        try {
            PaginationResult<User> result = new PaginationResult<User>();
            userService.addUser(user);
            result.setReturnCode(200);
            result.setReturnMsg("success");
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            PaginationResult<User> result = new PaginationResult<User>();
            result.setReturnCode(40002);
            result.setReturnMsg("add user failed");
            return  result;
        }
    }



    /**
     * 用户首页（同步分页，即必须等到数据查询出来才加载页面）
     *
     * @return
     */
    @RequestMapping("/index")
    public String index(@RequestParam(required = false, defaultValue = "1") Integer pageNo, @RequestParam(required = false, defaultValue = "2") Integer pageSize, Model model) {

        // 分页查询用户
        Map<String, Object> queryMap = new HashMap<String, Object>();
        queryMap.put("startNo", (pageNo - 1) * pageSize);
        queryMap.put("pageSize", pageSize);
        List<User> userList = userService.paginationQuery(queryMap);
        model.addAttribute("userList", userList);
        model.addAttribute("pageNo", pageNo);// 放入当前页码，方便前台做处理
        int totalCount = userService.paginationCount(queryMap);
        // 计算总页数
        int totalPage = totalCount / pageSize;
        if (totalCount == 0 || totalCount % pageSize != 0) {
            totalPage++;
        }
        model.addAttribute("totalPage", totalPage);// 放入总页码，方便前台做处理
        return "user/index";
    }



    /**
     * 用户首页（异步分页，即先加载完页面，数据通过ajax去异步加载）
     *
     * @return
     */
    @RequestMapping("/ajaxQueryUser")
    @ResponseBody
    public Object ajaxQueryUser(Integer pageNo, Integer pageSize,String queryText) {
        try {
            PaginationResult<User> result = new PaginationResult<User>();
            // 分页查询用户
            Map<String, Object> queryMap = new HashMap<String, Object>();
            queryMap.put("startNo", (pageNo - 1) * pageSize);
            queryMap.put("pageSize", pageSize);
            queryMap.put("queryText",queryText);
            List<User> userList = userService.paginationQuery(queryMap);
            // 计算总页数
            int totalCount = userService.paginationCount(queryMap);
            int totalPage = totalCount / pageSize;
            if (totalCount == 0 || totalCount % pageSize != 0) {
                totalPage++;
            }
            result.setReturnCode(200);
            result.setReturnMsg("success");
            result.setPageNo(pageNo);
            result.setTotalPage(totalPage);
            result.setData(userList);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            PaginationResult<User> result = new PaginationResult<User>();
            result.setReturnCode(40001);
            result.setReturnMsg("query user data failed");
            return result;
        }
    }

    /**
     * 用户首页（异步分页，即先加载完页面，数据通过ajax去异步加载）
     *
     * @return
     */
    @RequestMapping("/home")
    public String home() {
        return "user/index1";
    }



}
