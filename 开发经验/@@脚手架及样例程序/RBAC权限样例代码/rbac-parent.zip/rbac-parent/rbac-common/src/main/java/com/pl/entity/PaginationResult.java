package com.pl.entity;

import java.util.List;

/**
 * 封装分页结果
 */
public class PaginationResult<T> {

    private Integer returnCode;// 返回码

    private String returnMsg;// 返回信息

    private Integer pageNo;// 当前页码

    private Integer totalPage;// 总页数

    private List<T> data;// 返回数据

    public Integer getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(Integer returnCode) {
        this.returnCode = returnCode;
    }

    public String getReturnMsg() {
        return returnMsg;
    }

    public void setReturnMsg(String returnMsg) {
        this.returnMsg = returnMsg;
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(Integer totalPage) {
        this.totalPage = totalPage;
    }

    public List<T> getData() {
        return data;
    }

    public void setData(List<T> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "PaginationResult{" +
                "returnCode=" + returnCode +
                ", returnMsg='" + returnMsg + '\'' +
                ", pageNo=" + pageNo +
                ", totalPage=" + totalPage +
                ", data=" + data +
                '}';
    }
}
