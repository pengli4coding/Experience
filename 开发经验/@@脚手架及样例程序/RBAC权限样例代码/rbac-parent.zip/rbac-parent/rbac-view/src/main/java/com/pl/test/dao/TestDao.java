package com.pl.test.dao;

import com.pl.test.entity.TestEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TestDao {

    List<TestEntity> queryAll();
}
