package com.pl.controller;

import com.pl.entity.AJAXResult;
import com.pl.entity.User;
import com.pl.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;

/**
 * 专门用来跳转页面的controller
 */
@Controller
public class DispatcherController {

    @Autowired
    private UserService userService;

    @RequestMapping("/login")
    public String login(){
        return "login";
    }

    @RequestMapping("/main")
    public String main(){
        return "main";
    }

    @RequestMapping("/dologin")
    public String dologin(User user, Model model){

        // 获取表单数据的三种方式
        //1)通过HttpServletRequest获取表单数据
        //2)在方法参数列表中增加表单对应的参数，名称相同
        //3)将表单数据封装为实体类

        User dbUser = userService.query4Login(user);
        if(null != dbUser){
            return "main";
        } else{
            String errorMsg = "登录账号或密码不正确，请重新输入";
            model.addAttribute("errorMsg",errorMsg);
            return "redirect:login";
        }
    }

    @RequestMapping("/doAjaxLogin")
    @ResponseBody
    public Object doAjaxLogin(User user, HttpSession session){
        AJAXResult result = new AJAXResult();

        // 获取表单数据的三种方式
        //1)通过HttpServletRequest获取表单数据
        //2)在方法参数列表中增加表单对应的参数，名称相同
        //3)将表单数据封装为实体类

        User dbUser = userService.query4Login(user);
        if(null != dbUser){
            session.setAttribute("loginUser",dbUser);
            result.setSuccess(true);
        } else{
            result.setSuccess(false);
        }
        return result;
    }

    @RequestMapping("/logout")
    public String logout(HttpSession session){
        //session.removeAttribute("loginUser");
        session.invalidate();
        return "redirect:login";
    }
}
