package com.pl.test.service;

import com.pl.test.entity.TestEntity;

import java.util.List;

public interface TestService {

    List<TestEntity> queryAll();

}
