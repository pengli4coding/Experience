package com.pl.test.service.impl;

import com.pl.test.dao.TestDao;
import com.pl.test.entity.TestEntity;
import com.pl.test.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TestServiceImpl implements TestService {

    @Autowired
    private TestDao testDao;


    @Override
    public List<TestEntity> queryAll() {
        return testDao.queryAll();
    }
}
