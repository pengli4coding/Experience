package com.pl.test.controller;

import com.pl.test.entity.TestEntity;
import com.pl.test.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/test")
public class TestController {

    @Autowired
    private TestService testService;

    /**
     * 测试springmvc框架返回页面
     * @return
     */
    @RequestMapping("/view")
    public String index(){
        return "test";
    }

    /**
     * 测试springmvc框架返回json字符串
     * @return
     */
    @RequestMapping("/json")
    @ResponseBody
    public Object json(){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("username","小立立");
        map.put("age",29);
        return map;
    }

    @RequestMapping("/query")
    @ResponseBody
    public Object query(){
        List<TestEntity> list = testService.queryAll();
        return list;
    }

}
