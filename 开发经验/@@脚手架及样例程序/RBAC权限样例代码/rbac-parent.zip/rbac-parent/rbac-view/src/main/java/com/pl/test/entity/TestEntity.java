package com.pl.test.entity;

public class TestEntity {

    private Integer id;

    private String pet;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPet() {
        return pet;
    }

    public void setPet(String pet) {
        this.pet = pet;
    }

    @Override
    public String toString() {
        return "TestEntity{" +
                "id=" + id +
                ", pet='" + pet + '\'' +
                '}';
    }
}
