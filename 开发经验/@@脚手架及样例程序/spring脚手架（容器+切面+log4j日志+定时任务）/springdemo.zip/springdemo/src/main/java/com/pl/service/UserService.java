package com.pl.service;

import com.pl.model.User;

public interface UserService {

    boolean addUser(User user);
}
