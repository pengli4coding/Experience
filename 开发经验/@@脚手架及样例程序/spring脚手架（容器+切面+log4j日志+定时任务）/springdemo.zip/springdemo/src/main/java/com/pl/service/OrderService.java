package com.pl.service;

public interface OrderService {

    boolean placeOrder();
}
