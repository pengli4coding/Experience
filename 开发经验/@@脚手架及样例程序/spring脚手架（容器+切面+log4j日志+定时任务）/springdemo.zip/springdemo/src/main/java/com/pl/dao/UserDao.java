package com.pl.dao;

import com.pl.model.User;

public interface UserDao {

    boolean addUser(User user);
}
