package com.pl.test;

import com.pl.dao.EmployeeDao;
import com.pl.entity.Emp;
import com.pl.query.EmployeeQuery;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UnitTestEmployee {

    @Test
    public void testIfWhere() throws IOException, ParseException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            EmployeeDao dao = session.getMapper(EmployeeDao.class);
            EmployeeQuery query = new EmployeeQuery();
            //query.setEmpName("李");
            //query.setGender(1);
            //query.setEmail("963596521@qq.com");
            query.setAddress("北京");

            String start = "1983-06-01";
            String end = "1983-12-31";
            SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
            Date startDate = sf.parse(start);
            Date endDate = sf.parse(end);
            query.setStart(startDate);
            query.setEnd(endDate);

            List<Emp> list = dao.getEmployeesIfWhere(query);
            System.out.println("==================================================");
            for(Emp emp : list){
                System.out.println(emp);
            }
            System.out.println("==================================================");
        } finally {
            session.close();
        }
    }

    @Test
    public void testChooseWhen() throws IOException, ParseException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            EmployeeDao dao = session.getMapper(EmployeeDao.class);
            EmployeeQuery query = new EmployeeQuery();
            query.setEmpName("李");
            query.setGender(1);
            query.setEmail("963596521@qq.com");
            query.setAddress("");

            String start = "1983-06-01";
            String end = "1983-12-31";
            SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
            Date startDate = sf.parse(start);
            Date endDate = sf.parse(end);
            query.setStart(startDate);
            query.setEnd(endDate);

            List<Emp> list = dao.getEmployeesChooseWhen(query);
            System.out.println("==================================================");
            for(Emp emp : list){
                System.out.println(emp);
            }
            System.out.println("==================================================");
        } finally {
            session.close();
        }
    }

    @Test
    public void testSet() throws IOException, ParseException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            EmployeeDao dao = session.getMapper(EmployeeDao.class);
            Emp emp = new Emp();
            emp.setEmpId(9);
            emp.setAddress("杭州");
            emp.setEmail("666666666@qq.com");
            emp.setPassword("e10adc3949ba59abbe56e057f20f883e");
            dao.updateEmployee(emp);
            session.commit();// 手动提交事务
        } finally {
            session.close();
        }
    }

    @Test
    public void testForeach() throws IOException, ParseException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            EmployeeDao dao = session.getMapper(EmployeeDao.class);
            List<String> queryList = new ArrayList<String>();
            queryList.add("北京");
            queryList.add("上海");
            List<Emp> list = dao.getEmployeesForeach(queryList);
            System.out.println("==================================================");
            for(Emp emp : list){
                System.out.println(emp);
            }
            System.out.println("==================================================");
        } finally {
            session.close();
        }
    }

    @Test
    public void testBatchInsert() throws IOException, ParseException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            EmployeeDao dao = session.getMapper(EmployeeDao.class);
            List<Emp> empList = new ArrayList<Emp>();
            Emp emp1 = new Emp("陈钰琪", "999999999@qq.com", "15989502107", 0, "深圳", new SimpleDateFormat("yyyy-MM-dd").parse("1992-01-01"),"e10adc3949ba59abbe56e057f20f883e");
            Emp emp2 = new Emp("祝绪丹", "888888888@qq.com", "15989502108", 0, "深圳", new SimpleDateFormat("yyyy-MM-dd").parse("1992-02-01"),"e10adc3949ba59abbe56e057f20f883e");
            empList.add(emp1);
            empList.add(emp2);
            dao.employeesBatchInsert(empList);
            session.commit();
        } finally {
            session.close();
        }
    }
}
