package com.pl.test;

import com.pl.dao.UserDao;
import com.pl.entity.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

public class UnitTest {

    @Test
    public void testAddUser() throws IOException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            UserDao userDao = session.getMapper(UserDao.class);
            User user = new User();
            user.setUsername("刘兴富");
            user.setSex("男");
            user.setAge(30);
            user.setCreateTime(new Date());
            userDao.addUser(user);
            session.commit();// 需要手动提交事务
        } finally {
            session.close();
        }
    }

    @Test
    public void testDeleteUser() throws IOException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            UserDao userDao = session.getMapper(UserDao.class);
            userDao.deleteUser(1);
            session.commit();
        } finally {
            session.close();
        }
    }

    @Test
    public void testUpdateUser() throws IOException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            UserDao userDao = session.getMapper(UserDao.class);
            User user = new User();
            user.setId(2);
            user.setUsername("张小珊");
            user.setSex("女");
            user.setAge(30);
            user.setCreateTime(new Date());
            userDao.updateUser(user);
            session.commit();// 需要手动提交事务
        } finally {
            session.close();
        }
    }

    @Test
    public void testGetUser() throws IOException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            UserDao userDao = session.getMapper(UserDao.class);
            User user = userDao.getUser(1);
            System.out.println(user);
        } finally {
            session.close();
        }
    }

    @Test
    public void testAddUserAndReturnKey() throws IOException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            UserDao userDao = session.getMapper(UserDao.class);
            User user = new User();
            user.setUsername("刘兴富");
            user.setSex("男");
            user.setAge(30);
            user.setCreateTime(new Date());
            userDao.addUserAndReturnKey(user);
            System.out.println("插入数据后返回的主键值为：" + user.getId());// 打印插入数据后返回的主键值
            session.commit();// 需要手动提交事务
        } finally {
            session.close();
        }
    }


}
