package com.pl.test;

import com.pl.dao.EmpDao;
import com.pl.entity.Emp;
import com.pl.query.EmpQuery;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class UnitTestEmp {

    @Test
    public void testGetEmp1() throws IOException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            EmpDao empDao = session.getMapper(EmpDao.class);
            EmpQuery query = new EmpQuery();
            query.setEmpName("李晨");
            query.setGender(1);
            Emp emp = empDao.getEmp1(query);
            System.out.println(emp);
        } finally {
            session.close();
        }
    }

    @Test
    public void testGetEmp2() throws IOException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            EmpDao empDao = session.getMapper(EmpDao.class);
            Emp emp = empDao.getEmp2("李晨",1);
            System.out.println(emp);
        } finally {
            session.close();
        }
    }

    @Test
    public void testGetEmp3() throws IOException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            EmpDao empDao = session.getMapper(EmpDao.class);
            Emp emp = empDao.getEmp3("李晨",1);
            System.out.println(emp);
        } finally {
            session.close();
        }
    }

    @Test
    public void testGetEmp4() throws IOException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession session = sqlSessionFactory.openSession();// 这种方式获取的session需要手动提交事务
        try {
            EmpDao empDao = session.getMapper(EmpDao.class);
            Map<String,Object> map = new HashMap<String,Object>();
            map.put("na", "李晨");
            map.put("ge", 1);
            Emp emp = empDao.getEmp4(map);
            System.out.println(emp);
        } finally {
            session.close();
        }
    }
}
