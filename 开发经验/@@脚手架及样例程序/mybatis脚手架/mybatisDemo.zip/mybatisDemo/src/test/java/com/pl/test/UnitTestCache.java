package com.pl.test;

import org.junit.Test;

public class UnitTestCache {

    @Test
    public void test(){

    }

}
