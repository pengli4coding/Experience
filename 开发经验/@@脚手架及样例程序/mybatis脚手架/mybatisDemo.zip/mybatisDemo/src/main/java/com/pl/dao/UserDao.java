package com.pl.dao;

import com.pl.entity.User;

public interface UserDao {

    /**
     * 增
     * @param user
     */
    void addUser(User user);

    /**
     * 删
     * @param id
     */
    void deleteUser(Integer id);

    /**
     * 改
     * @param user
     */
    void updateUser(User user);

    /**
     * 查
     * @param id
     * @return
     */
    User getUser(Integer id);

    /**
     * 增加记录并返回主键
     * @param user
     */
    void addUserAndReturnKey(User user);
}
