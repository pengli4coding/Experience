package com.pl.dao;

import com.pl.entity.Emp;
import com.pl.query.EmployeeQuery;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface EmployeeDao {

    // 使用if和where标签的示例，适用于哪个参数有值就在where后面加上条件
    List<Emp> getEmployeesIfWhere(EmployeeQuery query);

    // 使用choose和when标签的示例，适用于哪个参数有值单独用哪个参数查询
    List<Emp> getEmployeesChooseWhen(EmployeeQuery query);

    // 使用set标签的示例，适用于在更新数据库记录的时候，满足条件的时候才更新对应的字段
    void updateEmployee(Emp emp);

    // 使用foreach标签的示例，适用于in (值1,值2,值3..) 的情况
    List<Emp> getEmployeesForeach(@Param("addressList") List<String> list);

    // 使用foreach标签的示例，适用于批量插入的情况
    void employeesBatchInsert(@Param("empList") List<Emp> empList);

}
