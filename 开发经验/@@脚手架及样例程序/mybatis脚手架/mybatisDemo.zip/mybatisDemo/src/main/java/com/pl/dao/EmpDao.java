package com.pl.dao;

import com.pl.entity.Emp;
import com.pl.query.EmpQuery;
import org.apache.ibatis.annotations.Param;

import java.util.Map;

public interface EmpDao {

    /**
     * 获取雇员信息（方式一）
     * @param query
     * @return
     */
    Emp getEmp1(EmpQuery query);


    /**
     * 获取雇员信息（方式二）
     * @param name
     * @param gender
     * @return
     */
    Emp getEmp2(String name,Integer gender);


    /**
     * 获取雇员信息（方式三）
     * @param name
     * @param gender
     * @return
     */
    Emp getEmp3(@Param("name") String name, @Param("gender") Integer gender);

    /**
     * 获取雇员信息（方式四）
     * @param map
     * @return
     */
    Emp getEmp4(Map<String,Object> map);

}
