package com.pl.dao;

public interface CacheDao {

}
