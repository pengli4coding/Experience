package com.pl.dao;

import com.pl.model.Emp;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmpDao {

    List<Emp> getAllEmps();
}
